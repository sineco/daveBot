from setuptools import setup

setup(name='daveBot',
      version='0.1',
      description='Plasticity Natural Language Understanding library',
      url='http://github.com/sineco/daveBot',
      author='Rodrigo Araujo',
      author_email='rodrigo@plasticitylabs.com',
      license='',
      packages=['daveBot'],
      zip_safe=False)
